enum APIRequestStatus {
  unInitialized,
  loading,
  loaded,
  error,
  connectionError,
}
